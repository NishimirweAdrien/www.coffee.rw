<?php
namespace Controllers;

// Include dependencies
require_once __DIR__ . '/../models/Setting.php';
require_once __DIR__ . '/../config/Response.php';

use Models\Setting;
use Config\Response;

class SettingController
 {
    private $settingModel;

    public function __construct()
 {
        $this->settingModel = new Setting();
    }

    public function getAllRoles()
 {
        $setting = $this->settingModel->getRoles();

        if ( $setting !== false ) {
            Response::success( 'Roles retrieved successfully!', $setting );
        } else {
            Response::error( 'Failed to retrieve users', 500 );
        }
    }

    public function getAllLocation() {
        $setting = $this->settingModel->getLocation();

        if ( $setting !== false ) {
            Response::success( 'Location retrieved successfully!', $setting );
        } else {
            Response::error( 'Failed to retrieve users', 500 );
        }
    }
}
