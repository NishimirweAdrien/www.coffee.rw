<?php
require __DIR__ . '/../_ikawa/config/App.php';
require __DIR__ . '/../_ikawa/middleware/auth.php';

$page = $_GET[ 'page' ] ?? 'dashboard';

// whitelist of allowed pages
$allowed_pages = [
    'dashboard' => 'views/dashboard.php',
    'manage-users' => 'views/manage-users.php',

];

if ( isset( $allowed_pages[ $page ] ) ) {
    require __DIR__ . '/' . $allowed_pages[ $page ];
} else {
    http_response_code( 404 );
    echo '<h3>Page not found</h3>';
}
