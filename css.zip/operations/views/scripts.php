<script>
function loadContent(page) {
    document.querySelectorAll('.nav-tabs li').forEach(function(li) {
        li.classList.remove('active');
    });
    var clickedLink = event.currentTarget || event.srcElement;
    clickedLink.parentNode.classList.add('active');

    var xhr = new XMLHttpRequest();

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {

            document.getElementById('app').innerHTML = xhr.responseText;

            // CHOSEN
            if ($('.chosen').length) {
                $('.chosen').chosen({ width: '100%' });
            }

            // DATATABLE
            if ($('#data-table-basic').length) {

                // destroy if already exists
                if ($.fn.DataTable.isDataTable('#data-table-basic')) {
                    $('#data-table-basic').DataTable().destroy();
                }

                $('#data-table-basic').DataTable({
                    pageLength: 10,
                    lengthChange: true,
                    searching: true,
                    ordering: true,
                    autoWidth: false
                });
            }
        }
        else{
          document.getElementById('app').innerHTML = '<h3>Page not found</h3>';  
        }
    };

    xhr.open('GET', 'load.php?page=' + page, true);
    xhr.send();
}
</script>
<script>
$(document).ready(function () {

    // Handle Save User button
$(document).on('click', '#saveUserBtn', function () {
    const btn = this;
    setButtonLoading(btn, true);
          const userData = {
            first_name: $('#first_name').val().trim(),
            last_name: $('#last_name').val().trim(),
            email: $('#email').val().trim(),
            username: $('#username').val().trim(),
            phone: $('#phone').val().trim(),
            role_id: $('#role_id').val(),
            gender: $('#gender').val(),
            nid: $('#nid').val().trim(),
            loc_id: $('#loc_id').val()
        };

        if (!userData.username || !userData.role_id || !userData.loc_id) {
            showToast('Please fill all required fields!', 'error');
            return;
        }

        $.ajax({
            url: '<?= App::baseUrl() ?>/_ikawa/users/create',
            method: 'POST',
            contentType: 'application/json',
            dataType: 'json',
            data: JSON.stringify(userData),
            success: function (response) {
                if (response.success) {
                    showToast(response.message, 'success');

                    $('#myModalthree').modal('hide');
                    $('#myModalthree input').val('');
                    $('#myModalthree select').val('').trigger('chosen:updated');
                    loadUsers();
                } else {
                    showToast(response.message, 'error');
                }
            },
            error: function (xhr) {
                let msg = 'Something went wrong';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    msg = xhr.responseJSON.message;
                }
                showToast(msg, 'error');
            },
        complete: function() {
            setButtonLoading(btn, false); // always reset button
        }
        });

    // Initialize DataTable
    const userTable = $('#data-table-basic').DataTable({
        destroy: true,
        pageLength: 10
    });

    // Function to load users from API and populate DataTable
    function loadUsers() {
        $.getJSON('<?= App::baseUrl() ?>/_ikawa/users/get-all-users', function (res) {
            if (!res.success) return;

            userTable.clear();

            $.each(res.data, function (index, user) {
                userTable.row.add([
                index + 1,
                user.first_name,
                user.last_name,
                user.username,
                user.phone,
                user.role_name,
                `<div class="button-icon-btn button-icon-btn-rd">
                    <button class="btn btn-default btn-icon-notika edituser"
                        title="Edit User"
                        data-id="${user.user_id}"
                        data-first_name="${user.first_name}"
                        data-last_name="${user.last_name}"
                        data-email="${user.email}"
                        data-username="${user.username}"
                        data-phone="${user.phone}"
                        data-role_id="${user.role_id}"
                        data-gender="${user.gender}"
                        data-nid="${user.nid}"
                        data-loc_id="${user.loc_id}"
                    >
                        <i class="notika-icon notika-edit"></i>
                    </button>
                    <button class="btn btn-default btn-icon-notika deleteuser" title="Delete User" data-id="${user.user_id}">
                        <i class="notika-icon text-danger notika-trash"></i>
                    </button>
                </div>`
            ]);
});


            userTable.draw(false);
        });
    }
    });

$(document).on('click', '.edituser', function() {
    const btn = $(this);

    // Fill modal fields
    $('#edit_first_name').val(btn.data('first_name'));
    $('#edit_last_name').val(btn.data('last_name'));
    $('#edit_email').val(btn.data('email'));
    $('#edit_username').val(btn.data('username'));
    $('#edit_phone').val(btn.data('phone'));
    $('#edit_role_id').val(btn.data('role_id')).trigger('chosen:updated');
    $('#edit_gender').val(btn.data('gender')).trigger('chosen:updated');
    $('#edit_nid').val(btn.data('nid'));
    $('#edit_loc_id').val(btn.data('loc_id')).trigger('chosen:updated');
    $("#user_id").val( btn.data('id'));
    $('#myModalfour').modal('show');
});


});
</script>
<script>
// Session expiry countdown
function startSessionCountdown(remainingSeconds) {
    // If less than 10 seconds remain, show modal immediately
    if (remainingSeconds <= 10) {
        showSessionModal(remainingSeconds);
        return;
    }
    
    // Calculate when to show the modal (10 seconds before expiry)
    const timeToShowModal = (remainingSeconds - 10) * 1000;
    
    setTimeout(function() {
        showSessionModal(10);
    }, timeToShowModal);
}

function showSessionModal(seconds) {
    const modal = document.getElementById('sessionModal');
    const countdown = document.getElementById('sessionCountdown');
    const logoutBtn = document.getElementById('logoutNow');
    const extendBtn = document.getElementById('extendSession');
    
    modal.style.display = 'block';
    countdown.textContent = seconds;
    
    // Disable background clicks
    modal.style.pointerEvents = 'auto';
    
    let remaining = seconds;
    let timer = null;
    
    // Start countdown
    timer = setInterval(() => {
        remaining--;
        countdown.textContent = remaining;
        
        if (remaining <= 0) {
            clearInterval(timer);
            performLogout();
        }
    }, 1000);
    
    // Logout button
    logoutBtn.onclick = function() {
        clearInterval(timer);
        performLogout();
    };
    
    // Extend session button
    extendBtn.onclick = function() {
        clearInterval(timer);
        extendSession();
    };
    
    // Close modal on background click
    modal.onclick = function(e) {
        if (e.target === modal) {
            // Don't allow closing by clicking background
            return;
        }
    };
}

function performLogout() {
    // Optional: Send logout request
    fetch('<?= App::baseUrl() ?>/_ikawa/auth/logout', {
        method: 'POST',
        credentials: 'same-origin'
    }).finally(() => {
        window.location.href = "<?= App::baseUrl() ?>/public/";
    });
}

function extendSession() {
    const extendBtn = document.getElementById('extendSession');
    const originalText = extendBtn.textContent;
    
    // Show loading
    extendBtn.disabled = true;
    extendBtn.textContent = 'Extending...';
    extendBtn.style.opacity = '0.7';
    
    fetch('<?= App::baseUrl() ?>/_ikawa/auth/extend-session', {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/json',
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Hide modal
            document.getElementById('sessionModal').style.display = 'none';
            
            // Show success toast
            showToast('Session extended successfully!', 'success');
            
            // Restart countdown check after 50 minutes
            setTimeout(() => {
                checkSessionStatus();
            }, 50 * 60 * 1000); // 50 minutes
        } else {
            showToast('Failed to extend session', 'error');
            // Restart countdown from 10 seconds
            setTimeout(() => showSessionModal(10), 1000);
        }
    })
    .catch(error => {
        showToast('Error extending session', 'error');
        // Restart countdown from 10 seconds
        setTimeout(() => showSessionModal(10), 1000);
    })
    .finally(() => {
        // Restore button
        extendBtn.disabled = false;
        extendBtn.textContent = originalText;
        extendBtn.style.opacity = '1';
    });
}

// Function to check session status periodically
function checkSessionStatus() {
    fetch('<?= App::baseUrl() ?>/_ikawa/auth/check-session', {
        credentials: 'same-origin'
    })
    .then(response => response.json())
    .then(data => {
        if (data.remainingSeconds && data.remainingSeconds > 0) {
            startSessionCountdown(data.remainingSeconds);
        } else if (data.remainingSeconds <= 0) {
            // Session already expired
            performLogout();
        }
    })
    .catch(error => {
        console.error('Session check failed:', error);
    });
}

// Initialize when page loads
$(document).ready(function() {
    // Start session countdown if we have the remaining time
    <?php if (isset($_SESSION['session_expires_in']) && $_SESSION['session_expires_in'] > 0): ?>
    startSessionCountdown(<?= $_SESSION['session_expires_in'] ?>);
    
    // Also check every 5 minutes in case of tab inactivity
    setInterval(checkSessionStatus, 5 * 60 * 1000);
    <?php endif; ?>
    
    // Your existing button handlers...
    $(document).on('click', '.edituser', function() {
        // Your existing edit user code...
    });
});
</script>