<?php
require __DIR__ . '/../pages/header.php';
require __DIR__ . '/../pages/navbar.php';
require __DIR__ . '/../pages/welcometop.php';
?>

<div id = 'app'>
<?php require __DIR__ . '/views/sign-in.php';
?>
</div>

<?php
require __DIR__ . '/../pages/footer.php';
?>
